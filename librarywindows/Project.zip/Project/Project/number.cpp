#include "number.h"
namespace MathLibrary {
	
		number::number() {
	       value = 0;
		}
		number::number(double a) {
			value = a;
		}

		number number::create(double a) {
			return number(a);
		}
		number number::operator+(const number& other) const {
			return number(value + other.value);
		 }
		number number::operator-(const number& other) const {
			return number(value - other.value);
		}
		number number::operator*(const number& other) const {
			return number(value * other.value);
		}
		number number::operator/(const number& other) const {
			if (other.value == 0) {
				return zero;
			}
			else
			return number(value / other.value);
		}
		double number::getvalue() const{
			return value;
		}
		void number::setvalue(double a) {
			value = a;
		}

}