#pragma once

namespace MathLibrary {
	class  number {
	private:
		double value;
	public:
		number();
		number(double a);

		


		static number create(double value);

		number operator+(const number& other) const;
		number operator-(const number& other) const;
		number operator*(const number& other) const;
		number operator/(const number& other) const;

		double getvalue() const;
		void setvalue(double a);
	};

	inline  const number zero{ 0.0 };
	inline  const number one{ 1.0 };
}