// maintest.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "number.h"
#include  "vector.h"
using namespace VectorLibrary;
using namespace MathLibrary;

int main()
{   

    std::cout << "=== Testing Vector and Number Libraries ===" << std::endl;

    std::cout << "\n Number Library Test:" << std::endl;

    number num1 = number::create(15.5);
    number num2 = number::create(3.2);
    number num3(9.8);

    std::cout << "Number 1: " << num1.getvalue() << std::endl;
    std::cout << "Number 2: " << num2.getvalue() << std::endl;
    std::cout << "Number 3: " << num3.getvalue() << std::endl;

    number sum = num1 + num2;
    number diff = num1 - num2;
    number product = num1 * num2;
    number quotient = num1 / num2;
    
    std::cout << "Sum: " << sum.getvalue() << std::endl;
    std::cout << "Difference: " << diff.getvalue() << std::endl;
    std::cout << "Product: " << product.getvalue() << std::endl;
    std::cout << "Quotient: " << quotient.getvalue() << std::endl;

 
    std::cout << "Zero: " << zero.getvalue() << std::endl;
    std::cout << "One: " << one.getvalue() << std::endl;

   

   
    
    std::cout << "\n Vector Library Test:" << std::endl;

   
    std::cout << "Zero vector: ";
    Vector::Zero.Print();

    std::cout << "One vector: ";
    Vector::One.Print();

    Vector v1 = Vector::Create(MathLibrary::number::create(3.0),
        MathLibrary::number::create(4.0));
    Vector v2 = Vector::Create(MathLibrary::number::create(1.0),
        MathLibrary::number::create(2.0));

    std::cout << "Vector 1: ";
    v1.Print();

    std::cout << "Vector 2: ";
    v2.Print();


    Vector su = v1 + v2;
    std::cout << "v1 + v2 = ";
    su.Print();

    std::cout << "Vector 1 - Radius: " << v1.GetRadius().getvalue()
        << ", Angle: " << v1.GetAngle().getvalue() << " rad" << std::endl;

    std::cout << "Vector 2 - Radius: " << v2.GetRadius().getvalue()
        << ", Angle: " << v2.GetAngle().getvalue() << " rad" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
