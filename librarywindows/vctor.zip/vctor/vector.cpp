﻿
#include "vector.h"
#include "pch.h"
#include <iostream>
#include <cmath>

namespace VectorLibrary
{
    const Vector Vector::Zero = Vector(MathLibrary::zero, MathLibrary::zero);
    const Vector Vector::One = Vector(MathLibrary::one, MathLibrary::one);

    Vector::Vector() : x(MathLibrary::zero), y(MathLibrary::zero) {}

    Vector::Vector(const MathLibrary::number& x_val, const MathLibrary::number& y_val)
        : x(x_val), y(y_val) {}

    Vector Vector::Create(const MathLibrary::number& x_val, const MathLibrary::number& y_val)
    {
        return Vector(x_val, y_val);
    }

    MathLibrary::number Vector::GetX() const
    {
        return x;
    }

    MathLibrary::number Vector::GetY() const
    {
        return y;
    }

    MathLibrary::number Vector::GetRadius() const
    {

        MathLibrary::number x2 = x * x;
        MathLibrary::number y2 = y * y;    
        MathLibrary::number rad ( sqrt((x2 + y2).getvalue()));

        return rad;
    }

    MathLibrary::number Vector::GetAngle() const
    {
        double x_val = x.getvalue();
        double y_val = y.getvalue();

        double angle_rad = atan2(y_val, x_val);

        return MathLibrary::number(angle_rad);
    }

    Vector Vector::operator+(const Vector& other) const
    {
        MathLibrary::number new_x = x + other.x;
        MathLibrary::number new_y = y + other.y;
        return Vector(new_x, new_y);
    }

    Vector Vector::Add(const Vector& other) const
    {
        return *this + other;
    }


    void Vector::Print() const
    {
        std::cout << "Vector(" << x.getvalue() << ", " << y.getvalue() << ")";
        std::cout << " [Radius: " << GetRadius().getvalue() << ", Angle: " << GetAngle().getvalue() << "]" << std::endl;
    }
}