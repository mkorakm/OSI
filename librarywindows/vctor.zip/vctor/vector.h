
#pragma once

#ifdef VCTOR_EXPORTS
#define VECTOR_API __declspec(dllexport)
#else
#define VECTOR_API __declspec(dllimport)
#endif

#include "D:\Professional\osi\Project\Project\number.h"  

namespace VectorLibrary
{
    class VECTOR_API Vector
    {
    private:
        MathLibrary::number x;  
        MathLibrary::number y; 

    public:
        
        Vector();
        Vector(const MathLibrary::number& x_val, const MathLibrary::number& y_val);

       
        static const Vector Zero;
        static const Vector One;
       
        static Vector Create(const MathLibrary::number& x_val, const MathLibrary::number& y_val);

        MathLibrary::number GetX() const;
        MathLibrary::number GetY() const;

     
        MathLibrary::number GetRadius() const;    
        MathLibrary::number GetAngle() const;    

        Vector operator+(const Vector& other) const;  
        Vector Add(const Vector& other) const;       

        void Print() const;
    };
}
