#pragma once
#include "number.h"

namespace VectorLibrary {
    class Vector {
    private:
        MathLibrary::number x, y;
        
    public:
        Vector(MathLibrary::number x_val = MathLibrary::number::zero, 
               MathLibrary::number y_val = MathLibrary::number::zero);
        
        static Vector Create(MathLibrary::number x_val, MathLibrary::number y_val);
        
        void Print() const;
        
        MathLibrary::number GetRadius() const;
        MathLibrary::number GetAngle() const;
        
        Vector operator+(const Vector& other) const;
        
        static Vector Zero;
        static Vector One;
    };
}
