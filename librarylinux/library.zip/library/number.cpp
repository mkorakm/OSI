#include "number.h"
#include <iostream>

namespace MathLibrary {
    number number::zero(0.0);
    number number::one(1.0);

    number::number(double v) : value(v) {}

    number number::create(double v) {
        return number(v);
    }

    double number::getvalue() const {
        return value;
    }

    number number::operator+(const number& other) const {
        return number(this->value + other.value);
    }

    number number::operator-(const number& other) const {
        return number(this->value - other.value);
    }

    number number::operator*(const number& other) const {
        return number(this->value * other.value);
    }

    number number::operator/(const number& other) const {
        if (other.value == 0.0) return number(0.0);
        return number(this->value / other.value);
    }
}
