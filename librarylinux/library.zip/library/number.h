#pragma once

namespace MathLibrary {
    class number {
    private:
        double value;
        
    public:
        number(double v = 0.0);
        
        static number create(double v);
        static number zero;
        static number one;
        
        double getvalue() const;
        
        number operator+(const number& other) const;
        number operator-(const number& other) const;
        number operator*(const number& other) const;
        number operator/(const number& other) const;
    };
}
