#include <iostream>
#include "number.h"
#include "vector.h"

using namespace VectorLibrary;
using namespace MathLibrary;

int main() {
    std::cout << "=== Linux Test Start ===" << std::endl;

    number n1(10.0);
    number n2(20.0);
    std::cout << "Number sum: " << (n1 + n2).getvalue() << std::endl;

    Vector v1 = Vector::Create(number(3), number(4));
    std::cout << "Vector: ";
    v1.Print();
    std::cout << "Radius: " << v1.GetRadius().getvalue() << std::endl;

    return 0;
}
