#include "vector.h"
#include <iostream>
#include <cmath>

namespace VectorLibrary {
    using namespace MathLibrary;

    Vector Vector::Zero(number::zero, number::zero);
    Vector Vector::One(number::one, number::one);

    Vector::Vector(number x_val, number y_val) : x(x_val), y(y_val) {}

    Vector Vector::Create(number x_val, number y_val) {
        return Vector(x_val, y_val);
    }

    void Vector::Print() const {
        std::cout << "(" << x.getvalue() << ", " << y.getvalue() << ")" << std::endl;
    }

    number Vector::GetRadius() const {
        double val_x = x.getvalue();
        double val_y = y.getvalue();
        return number::create(std::sqrt(val_x * val_x + val_y * val_y));
    }

    number Vector::GetAngle() const {
        double val_x = x.getvalue();
        double val_y = y.getvalue();
        return number::create(std::atan2(val_y, val_x));
    }

    Vector Vector::operator+(const Vector& other) const {
        return Vector(this->x + other.x, this->y + other.y);
    }
}
